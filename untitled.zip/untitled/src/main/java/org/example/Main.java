package org.example;
import com.shaft.driver.SHAFT;
import io.restassured.http.ContentType;
import org.json.simple.JSONObject;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        SHAFT.API api = new SHAFT.API("https://jsonplaceholder.typicode.com");
        api.get("/posts").perform();
        int code=api.getResponseStatusCode();
        System.out.println("status code is " +  code);
        String response=api.getResponseBody();
        System.out.println("response is "+ response);
        String body= String.valueOf(api.getResponse());
        System.out.println("response is "+ body);
        int responsecode=api.getResponseStatusCode();
        System.out.println("status code is " +  responsecode);
        long restime=api.getResponseTime();
        SHAFT.Validations.verifyThat().number(restime).isLessThanOrEquals(613).perform();
        String value=api.getResponseJSONValue("$.id").toString();
        String vale=api.getResponseJSONValue("$[1].id").toString();
        SHAFT.Validations.verifyThat().object(value).isEqualTo(1).perform();
        SHAFT.Validations.verifyThat().object(vale).isEqualTo(2).perform();

        api = new SHAFT.API("https://reqres.in/");
        JSONObject bod= new JSONObject();
        bod.put("name","hatem");
        bod.put("job","tester");
        api.post("api/users").setRequestBody(bod).setContentType(ContentType.JSON).perform();
        String nam=api.getResponseJSONValue("$.name").toString();
        String job=api.getResponseJSONValue("$.job").toString();
        System.out.println("my name is "+ nam);
        System.out.println("my job is "+ job);
        int status=api.getResponseStatusCode();
        System.out.println("the status code is " + status);
        SHAFT.Validations.verifyThat().object(nam).isEqualTo("hatem").perform();
        SHAFT.Validations.verifyThat().object(job).isEqualTo("tester").perform();
        SHAFT.Validations.verifyThat().number(status).isEqualTo(201).perform();
    }
}